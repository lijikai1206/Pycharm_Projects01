from distutils.core import setup

setup(name='View', version='1.0',description='A simple example',
      author='',py_modules=['First01'])
